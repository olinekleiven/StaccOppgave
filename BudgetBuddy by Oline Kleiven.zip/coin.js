// Legg til en klikk-lytter til mynten
coin.addEventListener('click', () => {
    // Få myntens nåværende posisjon
    const coinRect = coin.getBoundingClientRect();
    const coinTop = coinRect.top;
    const coinLeft = coinRect.left;
  
    // Fjern mynten fra visningen
    coin.style.display = 'none';
  
    // Legg til mynten bak grisen
    pig.style.zIndex = '1';
  
    // Bruk CSS-animasjon for å få mynten til å bevege seg jevnt nedover
    coin.style.transition = 'top 2s ease-in-out';
    coin.style.top = coinTop + window.innerHeight + 'px';
  
    // Når animasjonen er fullført, gjenopprett mynten til opprinnelig posisjon og vis den igjen
    coin.addEventListener('transitionend', () => {
      coin.style.top = coinTop + 'px';
      coin.style.transition = '';
      pig.style.zIndex = '0';
      coin.style.display = 'block';
  
      // Vis teksten "You missed!" her
      const coinText = document.querySelector('.coin-text');
      coinText.style.display = 'block';
  
      // Legg til en animasjon for å fade ut teksten etter 4 sekunder
      setTimeout(() => {
        coinText.style.animation = 'fade-out 2s';
        setTimeout(() => {
          coinText.style.display = 'none';
          coinText.style.animation = '';
        }, 2000);
      }, 2000);
    }, { once: true }); // Bruk "once" for å sikre at hendleren kjører bare én gang
  });