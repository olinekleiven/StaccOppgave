document.addEventListener("DOMContentLoaded", function () {
    const transactions = [];
    const transactionList = document.getElementById("transactionList");
    const transactionChart = document.getElementById("transactionChart").getContext("2d");
    const addTransactionButton = document.getElementById("addknapp");
    const dateInput = document.getElementById("date");
    const amountInput = document.getElementById("amount");
    const descriptionInput = document.getElementById("description");

    addTransactionButton.addEventListener("click", addTransaction);

    flatpickr(dateInput, {
        dateFormat: "Y-m-d",
        enableTime: false,
    });

    amountInput.addEventListener("input", function () {
        let cleanedValue = this.value.replace(/[^0-9.]/g, "");
        const decimalCount = cleanedValue.split(".").length - 1;

        if (decimalCount > 1) {
            const parts = cleanedValue.split(".");
            cleanedValue = parts[0] + "." + parts.slice(1).join("");
        }

        this.value = "$" + cleanedValue;
    });

    function addTransaction() {
        const form = document.getElementById("transactionForm");
        const date = form.elements.date.value;
        const amount = parseFloat(form.elements.amount.value.replace(/\$/g, ""));
        const description = form.elements.description.value;

        if (isNaN(amount)) {
            alert("Please enter a valid amount.");
            return;
        }

        const newTransaction = {
            date: date,
            amount: amount,
            description: description,
        };

        transactions.push(newTransaction);
        form.reset();

        const confirmationMessage = document.getElementById("confirmationMessage");
        confirmationMessage.style.display = "block";
        confirmationMessage.textContent = "Transaction added successfully!";

        // Display transaction information in text boxes
        const transactionInfo = document.getElementById("transactionInfo");
        const transactionDate = document.getElementById("transactionDate");
        const transactionDescription = document.getElementById("transactionDescription");
        const transactionAmount = document.getElementById("transactionAmount");

        transactionDate.textContent = `Date: ${date}`;
        transactionDescription.textContent = `Description: ${description}`;
        transactionAmount.textContent = `Amount: $${amount}`;

        transactionInfo.style.display = "block";

        setTimeout(() => {
            confirmationMessage.style.display = "none";
        }, 3000);

        displayTransactionList(transactions);
        updateChart(transactions);
    }

    function displayTransactionList(transactions) {
        transactionList.innerHTML = "";
        transactions.forEach((transaction) => {
            const listItem = document.createElement("li");
            listItem.textContent = `${transaction.date}: $${transaction.amount} - ${transaction.description}`;
            transactionList.appendChild(listItem);
        });
    }

    function updateChart(transactions) {
        const transactionAmounts = transactions.map((transaction) => transaction.amount);
        const transactionDates = transactions.map((transaction) => transaction.date);

        new Chart(transactionChart, {
            type: "bar",
            data: {
                labels: transactionDates,
                datasets: [
                    {
                        label: "Amount",
                        data: transactionAmounts,
                        backgroundColor: "rgba(75, 192, 192, 0.2)",
                        borderColor: "rgba(75, 192, 192, 1)",
                        borderWidth: 1,
                    },
                ],
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                    },
                },
            },
        });
    }
});